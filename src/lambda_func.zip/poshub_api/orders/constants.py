EXTERNAL_API_URL = (
    "https://1be838c5858847f7ad2b09cb00bcc5ae_oas.api.mockbin.io"
)
