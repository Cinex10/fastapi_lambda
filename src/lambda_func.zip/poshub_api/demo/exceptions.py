class ExternalDemoException(Exception):
    """Exception raised for external demo errors."""
